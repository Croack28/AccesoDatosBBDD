package reto1Unidad2CRUD.gestionAlumnos.UI;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {
    
    public JButton btnMascotas;
    public JButton btnInstituto;

    public VentanaPrincipal() {
        setTitle("Menú Principal");
        setLayout(new FlowLayout());
        
        btnMascotas = new JButton("Abrir Menú Mascotas");
        btnInstituto = new JButton("Abrir Menú Instituto");
        
        add(btnMascotas);
        add(btnInstituto);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null); // Centra la ventana
        setVisible(true);
    }
}

