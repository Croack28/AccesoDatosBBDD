package reto1Unidad2CRUD.gestionAlumnos.UI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JButton;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;

public class VentanaMascotas extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    public JTextField textFieldID;        // Para el DNI del alumno
    public JTextField textFieldDNI;        // Para el DNI del alumno
    public JTextField textFieldNombre;      // Para el nombre de la mascota
    public JTextField textFieldEspecie;     // Para la especie de la mascota
    public JTextField textFieldFechaAdquisicion; 
    public JButton btnCargarTodos;          // Botón para cargar todas las mascotas
    public JButton btnCrear;                 // Botón para crear una nueva mascota
    public JButton btnEliminar;              // Botón para eliminar una mascota
    public JButton btnBuscar;                // Botón para buscar por DNI
    public JButton btnVolver;
    private JScrollPane scrollPane;
    public JList<String> jListaMascotas;    // Lista para mostrar las mascotas
    public DefaultListModel<String> modeloLista; // Modelo para la lista

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VentanaMascotas frame = new VentanaMascotas();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public VentanaMascotas() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout(0, 0));
        setContentPane(contentPane);
        
        scrollPane = new JScrollPane();
        contentPane.add(scrollPane, BorderLayout.CENTER);
        
        modeloLista = new DefaultListModel<>();
        jListaMascotas = new JList<String>(modeloLista);
        jListaMascotas.setVisibleRowCount(-1);
        jListaMascotas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jListaMascotas.setLayoutOrientation(JList.VERTICAL);
        scrollPane.setViewportView(jListaMascotas);
        
        JPanel panel = new JPanel();
        contentPane.add(panel, BorderLayout.EAST);
        panel.setLayout(new GridLayout(0, 2, 0, 0));
        
        JLabel lblID = new JLabel("ID Mascota (solo para borrar)");
        panel.add(lblID);
        
        textFieldID = new JTextField();
        panel.add(textFieldID);
        textFieldID.setColumns(10);
        
        JLabel lblDNI = new JLabel("DNI Alumno");
        panel.add(lblDNI);
        
        textFieldDNI = new JTextField();
        panel.add(textFieldDNI);
        textFieldDNI.setColumns(10);
        
        JLabel lblNombre = new JLabel("Nombre Mascota");
        panel.add(lblNombre);
        
        textFieldNombre = new JTextField();
        panel.add(textFieldNombre);
        textFieldNombre.setColumns(10);
        
        JLabel lblEspecie = new JLabel("Especie");
        panel.add(lblEspecie);
        
        textFieldEspecie = new JTextField();
        panel.add(textFieldEspecie);
        textFieldEspecie.setColumns(10);
        
        JLabel lblFecha = new JLabel("Fecha adquisicion");
        panel.add(lblFecha);
        
        textFieldFechaAdquisicion = new JTextField();
        panel.add(textFieldFechaAdquisicion);
        textFieldFechaAdquisicion.setColumns(10);
        
        JPanel panel_1 = new JPanel();
        contentPane.add(panel_1, BorderLayout.SOUTH);
        
        btnCargarTodos = new JButton("Cargar Todos");
        panel_1.add(btnCargarTodos);
        
        btnCrear = new JButton("Crear Nueva");
        btnCrear.setHorizontalAlignment(SwingConstants.RIGHT);
        panel_1.add(btnCrear);
        
        btnBuscar = new JButton("Buscar por DNI");
        btnBuscar.setHorizontalAlignment(SwingConstants.RIGHT);
        panel_1.add(btnBuscar);
        
        btnEliminar = new JButton("Eliminar");
        btnEliminar.setHorizontalAlignment(SwingConstants.RIGHT);
        panel_1.add(btnEliminar);
        
        btnVolver = new JButton("Volver");
        btnVolver.setHorizontalAlignment(SwingConstants.RIGHT);
        panel_1.add(btnVolver);
    }
}

