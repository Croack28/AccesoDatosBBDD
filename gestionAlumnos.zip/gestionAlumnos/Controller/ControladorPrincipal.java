package reto1Unidad2CRUD.gestionAlumnos.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import reto1Unidad2CRUD.gestionAlumnos.Model.IModeloAlumnos;
import reto1Unidad2CRUD.gestionAlumnos.Model.IModeloMascotas;
import reto1Unidad2CRUD.gestionAlumnos.UI.VentanaPrincipal;
import reto1Unidad2CRUD.gestionAlumnos.UI.VentanaMascotas;
import reto1Unidad2CRUD.gestionAlumnos.UI.VentanaAlumnos; // Asegúrate de tener una clase VentanaInstituto

public class ControladorPrincipal implements ActionListener {
    
    private VentanaPrincipal view;
    private IModeloMascotas model; // O cualquier otro modelo que uses para Instituto
    private IModeloAlumnos model2;

    public ControladorPrincipal(IModeloMascotas model,IModeloAlumnos model2) {
        this.model = model;
        this.model2 = model2;
        this.view = new VentanaPrincipal();
        
        this.view.btnMascotas.addActionListener(this);
        this.view.btnInstituto.addActionListener(this);
    }

	@Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.btnMascotas) {
            abrirMenuMascotas();
        } else if (e.getSource() == view.btnInstituto) {
            abrirMenuInstituto();
        }
    }

    private void abrirMenuMascotas() {
        VentanaMascotas ventanaMascotas = new VentanaMascotas(); // Asegúrate de que esta clase exista
        new ControladorGestionMascotas(model, ventanaMascotas); // Aquí pasas el modelo a tu controlador de mascotas
        view.dispose(); // Cierra la ventana principal si es necesario
    }

    private void abrirMenuInstituto() {
    	VentanaAlumnos ventanaAlumnos = new VentanaAlumnos(); // Asegúrate de que esta clase exista
        new ControladorGestionAlumnos(model2,ventanaAlumnos); // Aquí pasas el modelo a tu controlador de instituto
        view.dispose(); // Cierra la ventana principal si es necesario
    }
}
