package reto1Unidad2CRUD.gestionAlumnos.Controller;

import reto1Unidad2CRUD.gestionAlumnos.UI.VentanaMascotas;
import reto1Unidad2CRUD.gestionAlumnos.Model.IModeloAlumnos;
import reto1Unidad2CRUD.gestionAlumnos.Model.IModeloMascotas;
import reto1Unidad2CRUD.gestionAlumnos.Model.ModeloMascotaJDBC;
import reto1Unidad2CRUD.gestionAlumnos.Model.ModeloAlumnoJDBC;

public class GestionAlumnos {

	public static void main(String[] args) {
		 try {
			 IModeloMascotas modelo = new ModeloMascotaJDBC(); // O el modelo que estés utilizando
			 IModeloAlumnos modelo2 = new ModeloAlumnoJDBC(); // O el modelo que estés utilizando
		     new ControladorPrincipal(modelo,modelo2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

