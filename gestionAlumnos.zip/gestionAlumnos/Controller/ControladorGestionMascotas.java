package reto1Unidad2CRUD.gestionAlumnos.Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import reto1Unidad2CRUD.gestionAlumnos.Model.IModeloAlumnos;
import reto1Unidad2CRUD.gestionAlumnos.Model.IModeloMascotas;
import reto1Unidad2CRUD.gestionAlumnos.Model.Mascota; // Clase modelo de mascota
import reto1Unidad2CRUD.gestionAlumnos.Model.ModeloAlumnoJDBC;
import reto1Unidad2CRUD.gestionAlumnos.Model.ModeloMascotaJDBC;
import reto1Unidad2CRUD.gestionAlumnos.UI.VentanaMascotas;

public class ControladorGestionMascotas implements ActionListener, ListSelectionListener {

    private IModeloMascotas model; // Modelo de mascotas
    private VentanaMascotas view;  // Vista de mascotas

    public ControladorGestionMascotas(IModeloMascotas model, VentanaMascotas view) {
        this.model = model;
        this.view = view;
        anadirListeners(this);

        this.view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.view.pack();
        this.view.setLocationRelativeTo(null);
        this.view.setVisible(true);
    }

    private void anadirListeners(ControladorGestionMascotas controladorGestionMascotas) {
        view.btnCargarTodos.addActionListener(controladorGestionMascotas);
        view.btnCrear.addActionListener(controladorGestionMascotas);
        view.btnEliminar.addActionListener(controladorGestionMascotas);
        view.btnBuscar.addActionListener(controladorGestionMascotas);

        view.jListaMascotas.addListSelectionListener(controladorGestionMascotas);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        String actionCommand = event.getActionCommand();
        System.out.println("Estoy en actionPerformed con la opción " + actionCommand);

        switch (actionCommand) {
            case "Cargar Todos":
                cargarMascotas();
                break;
            case "Crear Nueva":
                guardarMascota();
                break;
            case "Eliminar":
                eliminarMascota();
                break;
            case "Buscar por DNI":
                buscarMascota();
                break;
        }
    }
    

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) { // Esto previene eventos dobles
            // Código para manejar la selección de una mascota en la lista
            int selectedIndex = view.jListaMascotas.getSelectedIndex();
            if (selectedIndex >= 0) {
                String selectedMascota = view.modeloLista.getElementAt(selectedIndex);
                // Extrae el DNI o el identificador de la mascota si es necesario
                // Aquí puedes implementar la lógica para cargar la mascota en los campos
            }
        }
    }

    private void cargarMascotas() {
        DefaultListModel<String> modelo = new DefaultListModel<>();
        List<Mascota> lista = model.getAll(); // Supone que tienes un método en el modelo para obtener todas las mascotas
        if (lista != null) {
            view.modeloLista.clear();
            for (Mascota mascota : lista) {
                view.modeloLista.addElement(mascota.toString()); // Ajusta esto según el formato que necesites
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay mascotas guardadas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarMascota() {
        String dni = view.textFieldDNI.getText();
        String nombre = view.textFieldNombre.getText();
        String especie = view.textFieldEspecie.getText();

        // Comprobar si el DNI existe en la tabla instituto
        if (!model.dniExists(dni)) {
            JOptionPane.showMessageDialog(null, "El DNI no existe en la tabla de alumnos", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Salir del método si el DNI no existe
        }

        Mascota mascota = new Mascota();
        mascota.setDNI(dni);
        mascota.setNombre(nombre);
        mascota.setEspecie(especie);

        boolean guardado = model.crear(mascota);
        if (guardado) {
            JOptionPane.showMessageDialog(null, "Se ha insertado correctamente la mascota", "Inserción correcta", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Ha habido un problema en la inserción", "Error inserción", JOptionPane.ERROR_MESSAGE);
        }
    }



    private void eliminarMascota() {
        String id = view.textFieldID.getText(); // O el identificador de la mascota
        boolean eliminado = model.eliminarMascota(id); // Método en tu modelo para eliminar la mascota
        if (eliminado) {
            JOptionPane.showMessageDialog(null, "Se ha eliminado correctamente la mascota", "Eliminación correcta", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Ha habido un problema en la eliminación", "Error eliminación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarMascota() {
        String dni = view.textFieldDNI.getText();
        List<Mascota> mascotasBuscadas = model.getMascotasPorDNI(dni); // Cambiado para obtener una lista

        view.modeloLista.clear(); // Limpiar la lista antes de agregar resultados

        if (!mascotasBuscadas.isEmpty()) {
            for (Mascota mascota : mascotasBuscadas) {
                view.modeloLista.addElement(mascota.toString()); // Agregar cada mascota a la lista
            }
        } else {
            JOptionPane.showMessageDialog(null, "No existe mascotas con ese DNI", "Error búsqueda", JOptionPane.ERROR_MESSAGE);
        }
    }

}

