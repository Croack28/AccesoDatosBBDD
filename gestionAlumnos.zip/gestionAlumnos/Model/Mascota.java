package reto1Unidad2CRUD.gestionAlumnos.Model;

public class Mascota {
    private String id; // Campo para ID de la mascota
    private String dni;
    private String nombre;
    private String especie;

    // Otros métodos y constructores

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDNI() {
        return dni;
    }

    public void setDNI(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    @Override
    public String toString() {
        return String.format("ID: %s, DNI: %s, Nombre: %s, Especie: %s", id, dni, nombre, especie);
    }
}

